package lab06;

import java.util.Scanner;

public class TestConsole {

	public static void main(String args[]){
		Student stud = new Student();
		Scanner e = new Scanner(System.in);
		System.out.println("Ta neree oruulna uu: ");
		String name = "daagii";
		System.out.println("Student name:"+name);
	   
		
		//Librarian librarian = new Librarian();
		//Pay_Fine("Davaajargal");
		//String names = stud.nextLine();
		//System.out.println(getYear(2002));
	}
}
