package lab06;

public class Non_Teaching_Staff extends Member{
	private String designation;

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	@Override
	void Request_Book() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void Return_Book() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void Renew_Book() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void Enquiry() {
		// TODO Auto-generated method stub
		
	}
	
}