package lab06;

import java.util.Date;

public class Bill{//тооцооны класс
	private int Bill_ID;
	private Date Date;
	private int Member_ID;
	private int Amount;
	
	public void Create_Bill(int Member_id){
		System.out.println("Тооцоо хийх: "+ Bill_ID);
		System.out.println(Date +"өдөр" + Member_ID+"хэрэглэгч"+Amount +"тооцоо хийсэн.");
	}
	public void Update_Bill(){
		Date date = new Date();
		Date = date;
		System.out.println(Date);//--->
	}
}
